#ifndef SERVER_HPP
#define SERVER_HPP

#include <sys/socket.h>
#include <netinet/in.h>
#include <unistd.h>
#include <cstring>
#include <iostream>
#include "Config.hpp"
// #include <arpa/inet.h>

#define BLUE    "\33[34m"
#define GREEN   "\33[32m"
#define RED     "\33[31m"
#define WHITE   "\33[97m"
#define RESET   "\33[0m" // No Colour

class Webserv;
class Config;

class Server {
    public:
        Server();
        ~Server();
        
        Webserv             &getWebServ();
        struct sockaddr_in  &getAddr();
        int                 &getFd();
        std::string const   &getUploadDir();
        std::string const   &getWebRoot();
        void                setFd(int const fd);
        void                setWebserv(Webserv* webserv); // Add a setter for the webserv pointer
        int                 openSocket();
        int                 setOptional();
        int                 setServerAddr();
        int                 ft_bind();
        int                 ft_listen();
		// int					openAndListenSockets();
    private:
        int                 						_fd;
        struct sockaddr_in  						_addr;
        std::string         						_uploadDir;
        std::string         						_webRoot;

        Webserv             						*_webserv;
};

#endif