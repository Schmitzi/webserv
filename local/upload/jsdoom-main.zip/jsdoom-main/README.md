<h1 align="center">
  JS Doom 🕹
</h1>

<img src="https://www.howtogeek.com/wp-content/uploads/2012/02/dosbox-header.png?width=1198&trim=1,1&bg-color=000&pad=1,1" />

### I'ts a Emulator? 📺

#### ✅ Yesssss, this is a emulator running in html with js component.
#### For this project i used JS DosBox api, and simple html structure to make this simple page.
